import React from 'react';
import { calculateCost } from '../src/js/utils/utils';


describe('calculate cost', () => {
    
        it('shoudl calculate total cost', () => {
        expect(calculateCost({quantity:1 , name:"oven" , weight:1 , shippingOption:{ground:1,priority:1}},0)).toEqual(0)
       })

})