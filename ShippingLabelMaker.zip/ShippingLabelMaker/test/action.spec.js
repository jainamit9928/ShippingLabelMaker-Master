import React from 'react';
import * as types from '../src/js/constants/constants';
import * as actionTypes from '../src/js/actions/actions';

describe('actions', () => {
    it('should set shipping details', () => {
        const shippingDetails = {totalCost:"" ,rAddress:{}, sAddress:{} };
        const expectedAction = {
            type: types.SET_SHIPPING_DETAIL,
           data:shippingDetails
        };
        expect(actionTypes.setShippingDetail(shippingDetails)).toEqual(expectedAction)
    })
});

describe('actions', () => {
    it('should set steps', () => {
        const steps = 1;
        const expectedAction = {
            type: types.SET_STEPS,
            data : steps
        };
        expect(actionTypes.setSteps(steps)).toEqual(expectedAction)
    })
});

