import _ from 'lodash'

export const calculateCost = (productDetails, shippingRate) =>  productDetails.weight * shippingRate * productDetails.quantity * (productDetails.shippingOption.ground === 1 ? 1 : 1.5)
export const addToStorage = () => {
        let username = "demoaccount"
        let password =  "Passw0rd"
        window.localStorage.setItem('username', JSON.stringify(username))
         window.localStorage.setItem('password', JSON.stringify(password))
    }
