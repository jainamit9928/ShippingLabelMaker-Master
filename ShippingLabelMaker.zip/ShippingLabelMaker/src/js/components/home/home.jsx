import React from 'react'
import Modal from '../core/modal'
import Login from '../core/login'
import { LOGIN_HEADER } from '../../constants/constants' 

export default class Home extends React.PureComponent {

    constructor(props) {
        super(props);
        this.state = {
            isModalOpen: true,
            hasError:false
        }
        this.onOpenModal = this.onOpenModal.bind(this)
        this.onCloseModal = this.onCloseModal.bind(this)

    }
    componentDidMount() {
        const status = JSON.parse(window.localStorage.getItem('status'))
        if(status == "login successfully"){
             this.setState({ isModalOpen: false })
        }
        
    }
     onOpenModal() {
        this.setState({ isModalOpen: true})
    }
    onCloseModal() {
        this.setState({ isModalOpen: false })
        this.props.history.push('/shippingDetail');
    }

    render() {

        return (
            <div>
            <Modal header={ LOGIN_HEADER } isOpen={this.state.isModalOpen} >
                <Login  onClose={this.onCloseModal} />
            </Modal>
           <ShoppingCart />
           </div>
        )
    }
}

const ShoppingCart = () => (
    <div className='component-block'>

        <div className='col-md-12'>
            <h2> Home Page</h2>
            <strong>Here you can add items to your cart.</strong><br />
             <strong>Page Under Development.</strong><br />
           
            
        </div>

    </div>
)
