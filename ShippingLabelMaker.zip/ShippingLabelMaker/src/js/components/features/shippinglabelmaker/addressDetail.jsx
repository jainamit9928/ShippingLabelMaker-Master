import React from 'react'
import PropTypes from 'prop-types'

const AddressDetail = (props) => {
    const {
        name,
        street,
        city,
        state,
} = props.address
const {
  onChange,
  onUpdate,
  hasError,
  goForwad,
  goBack,
  steps,
  header,
  addressType
} = props

    return (
        <div className='container'>
            <div className="col-md-3"></div>
            <form className='form-horizontal col-md-5'>
                <header>{ header }</header>
                <div className='form-group'>
                    <label>Name:</label>
                    <div>
                        <input className={ 'form-control' +" "+ addressType } name='name' data-type= { addressType } type='text' value={ name } onChange={ onChange } required/>
                    </div>
                </div>
                <div className='form-group'>
                    <label >Street:</label>
                    <div>
                        <input className={  'form-control' +" "+ addressType }  data-type= { addressType } name='street' type='text' value={ street } onChange={ onChange } required/>
                    </div>
                </div>
                <div className='form-group'>
                    <label>City:</label>
                    <div>
                        <input className={  'form-control' +" "+ addressType }  data-type= { addressType } name='city' type='text' value={ city } onChange={ onChange } required/>
                    </div>
                </div>
                <div className='form-group'>
                    <label>State:</label>
                    <div>
                        <input className={  'form-control' +" "+ addressType } data-type= { addressType } name='state' type='text' value={ state } onChange={ onChange } required/>
                    </div>
                </div>
                <div className='input-group'>
                    <button type='button' className='btn btn-default' value='cancel' onClick={ goBack } disabled={ steps === 1  }> Previous </button>
                    <button type='button' className='btn btn-info' value='save' onClick={ onUpdate } disabled={ hasError }>SAVE</button>
                    <button type='button' className='btn btn-default' value='cancel' onClick={ goForwad } disabled={ steps === 4 || hasError }> Next </button>
                </div>
            </form>
             <div className="col-md-4"></div>
        </div>
    )}

AddressDetail.propTypes = {
    onChange: PropTypes.func.isRequired,
    onUpdate:PropTypes.func.isRequired,
    goForwad:PropTypes.func,
    goBack:PropTypes.func,
    hasError: PropTypes.bool,
    steps: PropTypes.number.isRequired
}

export default AddressDetail