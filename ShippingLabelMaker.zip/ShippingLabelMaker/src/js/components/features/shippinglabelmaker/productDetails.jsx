import React from 'react'
import PropTypes from 'prop-types'
import NumberInput from 'react-number-input'


const ProductDetail = (props) => {
    console.log(props)
    const {
     weight,
     quantity,
     name
} = props.productDetails
const {
   ground,
   priority
} =  props.productDetails.shippingOption
const {
  onChange,
  onGetFinalInfo,
  hasError,
  goForwad,
  goBack,
  steps,
  header,
  addressType
} = props

let blockChars= (evt) => {
    if (evt.which < 48 || evt.which > 57)
    {
        evt.preventDefault();
    }
}
    return (
        <div className='container'>
            <div className="col-md-3"></div>
            <form className='form-horizontal col-md-5'>
                <header>{ header }</header>
                 <div className='form-group'>
                    <label>Product - Name:</label>
                    <div>
                        <input className={ 'form-control'+" "+addressType }  name='name'  type='text' value={ name } onChange={ onChange } required/>
                    </div>
                </div>
                <div className='form-group'>
                    <label>Product - Weight:</label>
                    <div>
                        <NumberInput className={ 'form-control'+" "+addressType } onKeyPress = { blockChars } value={ weight } name="weight"  onChange={ onChange } type="number"  placeholder="Enter weight in kg" min={0} format="0,0[.]00" />
                    </div>
                </div>
                <div className='form-group'>
                    <label>Product - Quantity:</label>
                    <div>
                        <NumberInput className={ 'form-control'+" "+addressType } onKeyPress = { blockChars } value={ quantity } name="quantity" onChange={ onChange } type="number"  placeholder="Enter quantity" min={0}  max={5}/>
                    </div>
                </div>
               
                <div className='form-group'>
                    <label>Shipping Option - Ground:</label>
                    <div>
                        <select name="ground" className='form-control shipping' value={ ground } onChange={onChange} required>
                                <option className='shipping' value="1">1</option>
                                <option className='shipping' value="2">2</option>
                        </select>
                    </div>
                </div>
                
                <div className='form-group'>
                    <label>Shipping Option - Priority:</label>
                    <div>
                        <select name="priority" className='form-control shipping' value={ priority } onChange={onChange} required>
                                <option className='shipping' value="1">1</option>
                                <option className='shipping' value="2">2</option>
                                <option className='shipping' value="3">3</option>
                        </select>
                    </div>
                </div>
                <div className='input-group'>
                    <button type='button' className='btn btn-default' value='cancel' onClick={ goBack } disabled={ steps === 1 }> Previous </button>
                    <button type='button' className='btn btn-info' value='save' onClick={ onGetFinalInfo } disabled={ hasError }>SAVE</button>
                    <button type='button' className='btn btn-default' value='cancel' onClick={ goForwad } disabled={ steps === 4 || hasError }> Next </button>
                </div>
            </form>
             <div className="col-md-4"></div>
        </div>
    )}

ProductDetail.propTypes = {
    onChange: PropTypes.func.isRequired,
    onGetFinalInfo:PropTypes.func.isRequired,
    goForwad:PropTypes.func,
    goBack:PropTypes.func,
    hasError: PropTypes.bool,
    steps: PropTypes.number.isRequired
}

export default ProductDetail