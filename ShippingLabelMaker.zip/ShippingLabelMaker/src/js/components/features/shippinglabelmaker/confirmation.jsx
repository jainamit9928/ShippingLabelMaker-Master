import React from 'react'
import PropTypes from 'prop-types'

const Confirmation = (props) => {
    const {
        productDetails,
        totalCost
} = props.shippingDetail


    const getUUID = function () {
        var d = new Date().getTime();
       var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c=='x' ? r : (r&0x3|0x8)).toString(16);
    });
        return uuid
    }

    return (
        <div className='container'>

            <div className='table-striped table-responsive'>
                <div className='row'>
                    <div className='col-md-6 row-block'>
                        <label className='col-md-2 col-md-offset-3'>Product-Name:</label>
                        <div className='col-md-4'>{productDetails.name}</div>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-6 row-block'>
                        <label className='col-md-2 col-md-offset-3'>Quantity</label>
                        <div className='col-md-4'>{productDetails.quantity}</div>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-6 row-block'>
                        <label className='col-md-2 col-md-offset-3'>Shipping Option</label>
                        <div className='col-md-4'>Ground:{productDetails.shippingOption.ground} &nbsp; Priority: {productDetails.shippingOption.priority}</div>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-6 row-block'>
                        <label className='col-md-2 col-md-offset-3'>Shipping Cost</label>
                        <div className='col-md-4'>{totalCost}</div>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-6 row-block'>
                        <label className='col-md-2 col-md-offset-3'>Tracking Id</label>
                        <div className='col-md-4'>{getUUID()}</div>
                    </div>
                </div>

            </div>
        </div>

    )
}

Confirmation.propTypes = {
    shippingDetail: PropTypes.object.isRequired,
}
export default Confirmation
