import React from 'react'
import { Link } from 'react-router-dom'
import classNames from 'classnames'

const NavBar = () => {

    const homeClass =  classNames({
      'active': location.pathname === '/',
    })
    const shippingClass =  classNames({
      'active': location.pathname.match(/^\/shippingDetail/),
    })
    
    return (
        <section className='topbar'>
            <ul  className='topnav nav-right'>
              <li>
                 <Link className={homeClass} to='/'>Home</Link>
                </li>
                <li>
                    <Link className={shippingClass} to='/shippingDetail'>ShippingDetail</Link>
                </li>
            </ul>
        </section>
    )
}

export default NavBar
