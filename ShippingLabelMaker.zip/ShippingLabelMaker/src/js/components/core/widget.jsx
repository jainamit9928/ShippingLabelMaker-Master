import React from 'react'
import { RECEIVER_HEADER, SENDER_HEADER, PRODUCT_DETAILS } from '../../constants/constants'
import Loader from 'react-loader'
import AddressDetail from '../features/shippinglabelmaker/addressDetail.jsx'
import ProductDetails from '../features/shippinglabelmaker/productDetails.jsx'
import ProductInfo from '../features/shippinglabelmaker/productInfo.jsx'

export default class Widget extends React.PureComponent {

    componentDidMount() {
     
    }

    render() {
    const { steps , hasError, onChange, onUpdate, goForwad, goBack , onGetFinalInfo , onConfirmOrder } =  this.props
    switch (this.props.steps) {
         
			case 1:
				return <AddressDetail header ={ RECEIVER_HEADER } addressType="receiver" address = { this.props.shippingDetail.receiverDetails } steps = { steps } hasError ={ hasError } onChange = { onChange } onUpdate ={ onUpdate } goForwad = { goForwad } goBack = { goBack } />
			case 2:
				return <AddressDetail header ={ SENDER_HEADER } addressType="sender" address = { this.props.shippingDetail.senderDetails } steps = { steps } hasError ={ hasError } onChange = { onChange } onUpdate ={ onUpdate } goForwad = { goForwad } goBack = { goBack } />
            case 3:
             return <ProductDetails header ={ PRODUCT_DETAILS } addressType="product" productDetails = { this.props.shippingDetail.productDetails } steps = { steps } hasError ={ hasError } onChange = { onChange }  goForwad = { goForwad } goBack = { goBack } onGetFinalInfo ={ onGetFinalInfo }/>
            case 4:
             return <ProductInfo shippingDetail = { this.props.shippingDetail } steps = { steps } hasError ={ hasError }  goForwad = { goForwad } goBack = { goBack } onConfirmOrder = { onConfirmOrder } />
            default:
             return <AddressDetail header ={ RECEIVER_HEADER } addressType="receiver" productDetails = { this.props.shippingDetail.receiverDetails } steps = { steps } hasError ={ hasError } onChange = { onChange } onUpdate ={ onUpdate } goForwad = { goForwad } goBack = { goBack } onConfirmOrder= { onConfirmOrder } />
		}
        
    }
}

