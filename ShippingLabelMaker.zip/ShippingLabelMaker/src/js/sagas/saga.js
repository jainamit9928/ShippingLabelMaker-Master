import { call, put, takeEvery, all, take, race, select } from 'redux-saga/effects'
import 'regenerator-runtime/runtime'
import _ from 'lodash'
import { addToStorage } from '../utils/utils'

//backgroundTask
export function* watchAndLog() {
  while (true) {
    yield take('*')
    yield select()
  }
}

export function* watchStartBackgroundTask() {
  addToStorage()
  while (true) {
    yield take('*')
    yield race({
      task: call(watchAndLog),
      cancel: take('CANCEL_TASK'),
    })
  }
}


export function* rootSaga() {
  yield all([watchStartBackgroundTask()])
}
