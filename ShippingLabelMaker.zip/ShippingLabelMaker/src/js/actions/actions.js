import * as types from '../constants/constants.js'

export const setShippingDetail = (data) => ({ type: types.SET_SHIPPING_DETAIL, data })
export const setSteps = (data) => ({ type: types.SET_STEPS, data })
