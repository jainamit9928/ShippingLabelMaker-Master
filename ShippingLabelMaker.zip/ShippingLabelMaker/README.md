# SHIPPING LABEL MAKER

STEPS  TO START

1) NPM INSTALL
2) NPM START
3) Production : npm build:prod

Description:
This named ShippingLabelMaker can be used for shipping process for any eCommerce.
It contains 2 pages 
Login:Used For Authentication
Please use below credentials
username:demoaccount
password:Passw0rd
HOME: under Devleopment
ShippingDetails:For shipping details